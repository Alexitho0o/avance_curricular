# Flujo códigos SIES MU a Extranjeros

## Orden operativo

1. Construir candidatos SIES desde oferta/puente.
2. Determinar sede gobernada.
3. Aplicar ajuste de sede si corresponde.
4. Regenerar candidatos con sede final.
5. Seleccionar código solo si es inequívoco o existe resolución institucional.
6. Descomponer COD_SED, COD_CAR, JOR y VERSION desde código final.
7. Aplicar bloqueos antes de exportar.
8. Generar puente oficial MU -> Extranjeros.
9. Extranjeros consume únicamente el puente y resoluciones institucionales.

## Pendientes

Los pendientes se conservan con `ES_APTO_PARA_EXTRANJEROS=NO` y no deben pasar a PES.

## Comando

```bash
bash scripts/ejecutar_integracion_mu_extranjeros_2026.sh
```
