#!/usr/bin/env bash
set -euo pipefail

ROOT="/Users/alexi/Documents/GitHub/avance_curricular"
LOG_DIR="$ROOT/resultados/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/integracion_mu_extranjeros_$(date +%Y%m%d_%H%M%S).log"

cd "$ROOT"

{
  echo "Inicio integracion MU -> Extranjeros: $(date -Iseconds)"
  python3 scripts/run_integracion_tests.py
  python3 scripts/generar_integracion_mu_extranjeros_2026.py
  python3 scripts/run_integracion_tests.py
  echo "Fin integracion MU -> Extranjeros: $(date -Iseconds)"
} 2>&1 | tee "$LOG"
