from __future__ import annotations

import re
from dataclasses import dataclass

import pandas as pd

CODE_RE = re.compile(r"^I(?P<ies>\d+)S(?P<sede>\d+)C(?P<carrera>\d+)J(?P<jornada>\d+)V(?P<version>\d+)$")


@dataclass(frozen=True)
class ParsedSiesCode:
    codigo: str
    ies: str
    sede: str
    carrera: str
    jornada: str
    version: str
    valido: bool


def clean(value: object) -> str:
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>"}:
        return ""
    return text


def parse_sies_code(code: object) -> ParsedSiesCode:
    text = clean(code).upper()
    m = CODE_RE.fullmatch(text)
    if not m:
        return ParsedSiesCode(text, "", "", "", "", "", False)
    return ParsedSiesCode(
        codigo=text,
        ies=m.group("ies"),
        sede=m.group("sede"),
        carrera=m.group("carrera"),
        jornada=m.group("jornada"),
        version=m.group("version"),
        valido=True,
    )


def split_sies_candidates(value: object) -> list[str]:
    return [x.strip().upper() for x in re.split(r"[|,;]", clean(value)) if x.strip()]


def _normalise_offer(offer_dim: pd.DataFrame) -> pd.DataFrame:
    if offer_dim is None or offer_dim.empty or "CODIGO_UNICO" not in offer_dim.columns:
        return pd.DataFrame(columns=["CODIGO_UNICO", "_SED", "_CAR", "_JOR", "_VER"])
    out = offer_dim.copy()
    out["CODIGO_UNICO"] = out["CODIGO_UNICO"].map(lambda x: clean(x).upper())
    parsed = out["CODIGO_UNICO"].map(parse_sies_code)
    out["_SED"] = parsed.map(lambda x: x.sede if x.valido else "")
    out["_CAR"] = parsed.map(lambda x: x.carrera if x.valido else "")
    out["_JOR"] = parsed.map(lambda x: x.jornada if x.valido else "")
    out["_VER"] = parsed.map(lambda x: x.version if x.valido else "")
    return out[out["CODIGO_UNICO"].ne("")].drop_duplicates(subset=["CODIGO_UNICO"])


def candidates_for_same_academic_components(final_code: object, offer_dim: pd.DataFrame) -> list[str]:
    parsed = parse_sies_code(final_code)
    if not parsed.valido:
        return []
    offer = _normalise_offer(offer_dim)
    if offer.empty:
        return []
    mask = (
        offer["_SED"].eq(parsed.sede)
        & offer["_CAR"].eq(parsed.carrera)
        & offer["_JOR"].eq(parsed.jornada)
        & offer["_VER"].eq(parsed.version)
    )
    return sorted(offer.loc[mask, "CODIGO_UNICO"].drop_duplicates().tolist())


def regenerate_candidates_after_sede_adjustment(
    df: pd.DataFrame,
    offer_dim: pd.DataFrame,
    *,
    final_col: str = "CODIGO_CARRERA_SIES_FINAL",
) -> tuple[pd.DataFrame, dict[str, int]]:
    """Regenerate SIES candidates after AJUSTE_SEDE_GOBERNANZA.

    Historical bug: `CODIGOS_SIES_POTENCIALES` could preserve candidates from
    the previous sede after `final_col` was replaced with the sede-adjusted code.
    This function updates candidate audit columns prospectively; it does not
    choose a new code.
    """
    out = df.copy()
    for col in ["CODIGOS_SIES_POTENCIALES", "N_CODES_SIES"]:
        if col not in out.columns:
            out[col] = ""
    if "CODIGOS_SIES_POTENCIALES_INICIALES" not in out.columns:
        out["CODIGOS_SIES_POTENCIALES_INICIALES"] = out["CODIGOS_SIES_POTENCIALES"]
    out["CODIGOS_SIES_POTENCIALES_FINALES"] = out["CODIGOS_SIES_POTENCIALES"]
    out["N_CANDIDATOS_INICIALES"] = out["CODIGOS_SIES_POTENCIALES_INICIALES"].map(lambda x: len(split_sies_candidates(x)))
    out["N_CANDIDATOS_FINALES"] = out["CODIGOS_SIES_POTENCIALES"].map(lambda x: len(split_sies_candidates(x)))

    adjusted = out.get("SIES_AJUSTE_SEDE_FLAG", pd.Series("", index=out.index)).astype(str).str.strip().eq("SI")
    changed = 0
    for idx in out.index[adjusted]:
        candidates = candidates_for_same_academic_components(out.at[idx, final_col], offer_dim)
        if not candidates:
            continue
        joined = " | ".join(candidates)
        out.at[idx, "CODIGOS_SIES_POTENCIALES_FINALES"] = joined
        out.at[idx, "CODIGOS_SIES_POTENCIALES"] = joined
        out.at[idx, "N_CANDIDATOS_FINALES"] = len(candidates)
        out.at[idx, "N_CODES_SIES"] = len(candidates)
        for i in range(1, 6):
            col = f"CODIGO_CARRERA_SIES_{i}"
            if col in out.columns:
                out.at[idx, col] = candidates[i - 1] if i <= len(candidates) else pd.NA
        changed += 1
    return out, {"ajustes_sede_regenerados": changed, "ajustes_sede_detectados": int(adjusted.sum())}


def reconstructed_code_from_components(row: pd.Series) -> str:
    sede = clean(row.get("COD_SED"))
    carrera = clean(row.get("COD_CAR"))
    jornada = clean(row.get("JOR"))
    version = clean(row.get("VERSION"))
    if not all([sede, carrera, jornada, version]) or not version.isdigit():
        return ""
    return f"I162S{sede}C{carrera}J{jornada}V{version}"


def apply_export_blockers(
    df: pd.DataFrame,
    estado_carga: pd.Series,
    offer_dim: pd.DataFrame,
    *,
    final_col: str = "CODIGO_CARRERA_SIES_FINAL",
) -> tuple[pd.Series, pd.DataFrame]:
    """Apply hard blockers before export. Returns updated state and audit df."""
    out = df.copy()
    state = estado_carga.copy()
    if "ESTADO_EXPORTACION_SIES" not in out.columns:
        out["ESTADO_EXPORTACION_SIES"] = ""
    if "MOTIVO_BLOQUEO_EXPORTACION_SIES" not in out.columns:
        out["MOTIVO_BLOQUEO_EXPORTACION_SIES"] = ""

    offer = _normalise_offer(offer_dim)
    offer_set = set(offer["CODIGO_UNICO"].tolist())

    final_code = out.get(final_col, pd.Series("", index=out.index)).map(lambda x: clean(x).upper())
    candidates = out.get("CODIGOS_SIES_POTENCIALES_FINALES", out.get("CODIGOS_SIES_POTENCIALES", pd.Series("", index=out.index)))
    candidates_list = candidates.map(split_sies_candidates)
    version = out.get("VERSION", pd.Series("", index=out.index)).map(clean)
    version_source = out.get("VERSION_FUENTE_FINAL", pd.Series("", index=out.index)).map(clean)
    version_method = out.get("VERSION_METODO_FINAL", pd.Series("", index=out.index)).map(clean)
    gobernanza = out.get("SIES_RESOLUCION_HEURISTICA", pd.Series("", index=out.index)).map(clean)

    reconstructed = out.apply(reconstructed_code_from_components, axis=1)
    ok = state.eq("OK_CARGA_PREGRADO")

    blockers: list[tuple[pd.Series, str, str]] = [
        (gobernanza.eq("PENDIENTE_GOBERNANZA"), "BLOQUEADO_PENDIENTE_GOBERNANZA", "ESTADO_GOBERNANZA=PENDIENTE_GOBERNANZA"),
        (final_code.eq(""), "BLOQUEADO_CODIGO_VACIO", "CODIGO_CARRERA_SIES_FINAL vacío"),
        (candidates_list.map(len).eq(0), "BLOQUEADO_CODIGO_FUERA_CANDIDATOS", "Candidatos finales vacíos"),
        (~final_code.eq("") & ~pd.Series([fc in cl for fc, cl in zip(final_code, candidates_list)], index=out.index), "BLOQUEADO_CODIGO_FUERA_CANDIDATOS", "Código final fuera de candidatos finales"),
        (~version.str.fullmatch(r"\d+", na=False), "BLOQUEADO_VERSION_SIN_TRAZA", "VERSION vacía o inválida"),
        (version_source.eq("") | version_source.str.startswith("SIN_"), "BLOQUEADO_VERSION_SIN_TRAZA", "VERSION_FUENTE_FINAL sin traza"),
        (version_method.eq("") | version_method.str.startswith("SIN_"), "BLOQUEADO_VERSION_SIN_TRAZA", "VERSION_METODO_FINAL sin traza"),
        (~final_code.eq("") & reconstructed.ne("") & reconstructed.ne(final_code), "BLOQUEADO_INCOMPATIBILIDAD_ACADEMICA", "Código reconstruido distinto del final"),
        (~final_code.eq("") & ~final_code.isin(offer_set), "BLOQUEADO_INCOMPATIBILIDAD_ACADEMICA", "Código final inexistente en oferta"),
    ]

    out["ESTADO_EXPORTACION_SIES"] = "APTO_EXPORTACION"
    for mask, status, reason in blockers:
        hit = ok & mask & state.eq("OK_CARGA_PREGRADO")
        if hit.any():
            state.loc[hit] = status
            out.loc[hit, "ESTADO_EXPORTACION_SIES"] = status
            out.loc[hit, "MOTIVO_BLOQUEO_EXPORTACION_SIES"] = reason

    out.loc[~state.eq("OK_CARGA_PREGRADO") & out["ESTADO_EXPORTACION_SIES"].eq(""), "ESTADO_EXPORTACION_SIES"] = state.loc[~state.eq("OK_CARGA_PREGRADO")]
    return state, out
